TUGASIN - VERSI FRONTEND (TANPA PHP DAN MYSQL)

Struktur:
- index.html       : struktur halaman
- css/style.css    : seluruh CSS/tampilan
- js/script.js     : seluruh JavaScript/fungsi aplikasi

Cara menjalankan:
1. Ekstrak folder Tugasin-Frontend.
2. Buka index.html menggunakan browser, atau jalankan dengan Live Server di VS Code.

Catatan:
- Data akun, tugas, tema, dan bahasa disimpan di localStorage/sessionStorage browser.
- Ini adalah versi frontend/demo, bukan autentikasi online yang aman.
- Tidak membutuhkan PHP, MySQL, XAMPP, atau Laragon.
- Bootstrap dimuat melalui CDN, sehingga koneksi internet diperlukan untuk tampilan Bootstrap.
