"use strict";

    // Penyimpanan lokal untuk DEMO, bukan autentikasi online yang aman.

    const K_AKUN = "tugasin_akun_v1";
    const K_TUGAS = "tugasin_tugas_v1";
    const K_SESI = "tugasin_sesi_v1";
    const K_PREF = "tugasin_pref_v1";

    const $ = id => document.getElementById(id);

    const baca = (k, cadangan) => {
      try {
        return JSON.parse(localStorage.getItem(k)) ?? cadangan;
      } catch {
        return cadangan;
      }
    };

    const simpan = (k, data) => {
      localStorage.setItem(k, JSON.stringify(data));
    };

    const akunSemua = () => baca(K_AKUN, []);
    const tugasSemua = () => baca(K_TUGAS, []);

    const user = () => {
      return akunSemua().find(
        a => a.id === sessionStorage.getItem(K_SESI)
      );
    };

    // PENGATURAN TAMPILAN (tema dan bahasa)

    const pref = Object.assign({ tema: "light", bahasa: "id" }, baca(K_PREF, {}));

    // KAMUS BAHASA

    const TEKS = {
      id: {
        title: "Tugasin - Pengelola Tugas Mahasiswa",
        authHero: "Semua tugas kuliah,<br>lebih teratur.",
        authDesc: "Catat deadline, atur prioritas, dan selesaikan tugas satu per satu tanpa perlu bingung.",
        stayProd: "Tetap produktif!",
        stayProdDesc: "Satu tempat untuk semua tugas yang perlu kamu kerjakan.",
        authFoot: "Tugasin - Website pengelola tugas mahasiswa",
        welcome: "Selamat datang!",
        loginDesc: "Masuk untuk melihat daftar tugasmu.",
        email: "Email",
        password: "Kata sandi",
        passPh: "Masukkan kata sandi",
        login: "Masuk",
        noAcc: "Belum punya akun?",
        regHere: "Daftar di sini",
        demoBtn: "Masuk akun demo",
        demoNote: "Mode demo frontend. Akun hanya disimpan pada browser ini. Jangan gunakan kata sandi asli.",
        createAcc: "Buat akun",
        regDesc: "Mulai kelola tugas kuliahmu.",
        fullName: "Nama lengkap",
        namePh: "Nama kamu",
        passMin: "Kata sandi (minimal 6 karakter)",
        regBtn: "Daftar akun",
        haveAcc: "Sudah punya akun?",
        loginHere: "Masuk di sini",
        navHome: "Beranda",
        navTasks: "Daftar tugas",
        navCal: "Kalender",
        navAdd: "+ Tambah tugas",
        navSet: "Pengaturan",
        logout: "Keluar",
        userDefault: "Pengguna",
        homeSub: "Halo, {n}! Yuk, cek progres tugasmu.",
        tasksSub: "Cari, kelola, dan selesaikan tugasmu.",
        calSub: "Lihat tanggal tenggat semua tugasmu.",
        addSub: "Isi informasi tugas dengan lengkap.",
        setSub: "Atur tema, bahasa, dan profilmu.",
        addTitle: "Tambah tugas",
        editTitle: "Edit tugas",
        statTotal: "Total tugas",
        statActive: "Belum selesai",
        statDone: "Selesai",
        statLate: "Terlambat",
        progress: "Progres penyelesaian",
        nearest: "Tugas terdekat",
        seeAll: "Lihat semua",
        searchPh: "Cari judul atau mata kuliah...",
        fAll: "Semua tugas",
        formTitle: "Judul tugas",
        titlePh: "Contoh: Laporan Praktikum Pemrograman",
        course: "Mata kuliah",
        coursePh: "Contoh: Dasar Pemrograman",
        due: "Tenggat waktu",
        priority: "Prioritas",
        pMed: "Sedang",
        pHigh: "Tinggi",
        pLow: "Rendah",
        status: "Status",
        notes: "Catatan",
        notesPh: "Catatan tentang tugas ini...",
        save: "Simpan tugas",
        cancel: "Batal",
        empty: "Belum ada tugas yang ditampilkan.",
        noDate: "Tanpa tanggal",
        deadline: "Deadline",
        reopen: "Buka lagi",
        markDone: "Selesai",
        edit: "Edit",
        del: "Hapus",
        confirmDel: "Hapus tugas ini?",
        errLogin: "Email atau kata sandi tidak cocok.",
        errShort: "Nama atau kata sandi terlalu pendek.",
        errDup: "Email ini sudah terdaftar.",
        errStorage: "Penyimpanan browser tidak tersedia.",
        calToday: "Hari ini",
        calTasksOn: "Tugas pada {d}",
        calAddHere: "+ Tambah di tanggal ini",
        calNone: "Tidak ada tugas pada tanggal ini.",
        calTaskCount: "{n} tugas",
        days: ["Sen", "Sel", "Rab", "Kam", "Jum", "Sab", "Min"],
        setTheme: "Tema",
        themeDesc: "Berlaku untuk seluruh halaman web.",
        themeLight: "Terang",
        themeDark: "Gelap",
        setLang: "Bahasa",
        langDesc: "Pilih bahasa tampilan.",
        setProfile: "Profil",
        profileDesc: "Ubah nama, ganti akun, atau keluar.",
        changeName: "Ubah nama",
        saveName: "Simpan nama",
        nameSaved: "Nama berhasil diperbarui.",
        errName: "Nama minimal 2 karakter.",
        switchAcc: "Ganti akun"
      },
      en: {
        title: "Tugasin - Student Task Manager",
        authHero: "All your coursework,<br>better organized.",
        authDesc: "Track deadlines, set priorities, and finish your tasks one by one without the confusion.",
        stayProd: "Stay productive!",
        stayProdDesc: "One place for every task you need to get done.",
        authFoot: "Tugasin - Student task manager website",
        welcome: "Welcome!",
        loginDesc: "Sign in to see your task list.",
        email: "Email",
        password: "Password",
        passPh: "Enter your password",
        login: "Sign in",
        noAcc: "Don't have an account?",
        regHere: "Sign up here",
        demoBtn: "Use demo account",
        demoNote: "Frontend demo mode. Accounts are stored in this browser only. Do not use a real password.",
        createAcc: "Create account",
        regDesc: "Start managing your coursework.",
        fullName: "Full name",
        namePh: "Your name",
        passMin: "Password (at least 6 characters)",
        regBtn: "Sign up",
        haveAcc: "Already have an account?",
        loginHere: "Sign in here",
        navHome: "Home",
        navTasks: "Task list",
        navCal: "Calendar",
        navAdd: "+ Add task",
        navSet: "Settings",
        logout: "Log out",
        userDefault: "User",
        homeSub: "Hi, {n}! Let's check your task progress.",
        tasksSub: "Search, manage, and finish your tasks.",
        calSub: "See the due dates of all your tasks.",
        addSub: "Fill in the task information completely.",
        setSub: "Manage your theme, language, and profile.",
        addTitle: "Add task",
        editTitle: "Edit task",
        statTotal: "Total tasks",
        statActive: "Pending",
        statDone: "Done",
        statLate: "Overdue",
        progress: "Completion progress",
        nearest: "Upcoming tasks",
        seeAll: "See all",
        searchPh: "Search title or course...",
        fAll: "All tasks",
        formTitle: "Task title",
        titlePh: "e.g. Programming Lab Report",
        course: "Course",
        coursePh: "e.g. Programming Basics",
        due: "Due date",
        priority: "Priority",
        pMed: "Medium",
        pHigh: "High",
        pLow: "Low",
        status: "Status",
        notes: "Notes",
        notesPh: "Notes about this task...",
        save: "Save task",
        cancel: "Cancel",
        empty: "No tasks to show.",
        noDate: "No date",
        deadline: "Deadline",
        reopen: "Reopen",
        markDone: "Done",
        edit: "Edit",
        del: "Delete",
        confirmDel: "Delete this task?",
        errLogin: "Email or password does not match.",
        errShort: "Name or password is too short.",
        errDup: "This email is already registered.",
        errStorage: "Browser storage is not available.",
        calToday: "Today",
        calTasksOn: "Tasks on {d}",
        calAddHere: "+ Add on this date",
        calNone: "No tasks on this date.",
        calTaskCount: "{n} tasks",
        days: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        setTheme: "Theme",
        themeDesc: "Applies to the whole website.",
        themeLight: "Light",
        themeDark: "Dark",
        setLang: "Language",
        langDesc: "Choose the display language.",
        setProfile: "Profile",
        profileDesc: "Change your name, switch account, or log out.",
        changeName: "Change name",
        saveName: "Save name",
        nameSaved: "Name updated successfully.",
        errName: "Name must be at least 2 characters.",
        switchAcc: "Switch account"
      }
    };

    function t(kunci, isi) {
      let s = (TEKS[pref.bahasa] || TEKS.id)[kunci];
      if (s === undefined) s = TEKS.id[kunci] ?? kunci;
      if (isi && typeof s === "string") {
        for (const k in isi) s = s.replace("{" + k + "}", isi[k]);
      }
      return s;
    }

    const lokal = () => pref.bahasa === "en" ? "en-US" : "id-ID";

    let halaman = "beranda";
    let panelAuth = "login";
    let asalForm = "tugas";
    let kalBulan = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
    let kalPilih = "";

    function buatId() {
      return (typeof crypto !== "undefined" && crypto.randomUUID)
        ? crypto.randomUUID()
        : String(Date.now()) + Math.random();
    }

    // MENAMPILKAN PESAN

    function pesan(id, isi, ok = false) {
      const e = $(id);
      e.textContent = isi;
      e.classList.toggle("ok", ok);
      e.classList.remove("d-none");
    }

    // TANGGAL

    const dua = n => String(n).padStart(2, "0");

    function tanggalHariIni() {
      const d = new Date();
      return `${d.getFullYear()}-${dua(d.getMonth() + 1)}-${dua(d.getDate())}`;
    }

    function tglIndo(s) {
      if (!s) return t("noDate");

      const [y, m, d] = s.split("-");
      return pref.bahasa === "en" ? `${m}/${d}/${y}` : `${d}/${m}/${y}`;
    }

    // MENGAMBIL TUGAS MILIK PENGGUNA

    function tugasUser() {
      const u = user();

      return u
        ? tugasSemua().filter(x => x.userId === u.id)
        : [];
    }

    function terlambat(x) {
      return x.status !== "selesai" &&
             x.deadline < tanggalHariIni();
    }

    function statusTugas(x) {
      if (x.status === "selesai") return "selesai";
      return terlambat(x) ? "terlambat" : "aktif";
    }

    function urutkan(data) {
      return [...data].sort((a, b) =>
        (a.status === "selesai") - (b.status === "selesai") ||
        a.deadline.localeCompare(b.deadline)
      );
    }

    function buatElemen(tag, kelas, teks) {
      const e = document.createElement(tag);
      if (kelas) e.className = kelas;
      if (teks !== undefined) e.textContent = teks;
      return e;
    }

    const namaPrioritas = p => ({ Tinggi: t("pHigh"), Sedang: t("pMed"), Rendah: t("pLow") }[p] || p);

    // MENAMPILKAN DAFTAR TUGAS

    function isiDaftar(id, data, teksKosong) {
      const wadah = $(id);
      wadah.replaceChildren();

      if (data.length === 0) {
        wadah.append(
          buatElemen("div", "kosong", teksKosong || t("empty"))
        );
        return;
      }

      data.forEach(x => {
        const baris = buatElemen(
          "article",
          "baris-tugas" + (x.status === "selesai" ? " selesai" : "")
        );

        const kiri = buatElemen("div");
        kiri.style.minWidth = "0";

        kiri.append(
          buatElemen("h3", "nama-tugas", x.judul)
        );

        kiri.append(
          buatElemen(
            "div",
            "detail-tugas",
            `${x.matkul} - ${t("deadline")}: ${tglIndo(x.deadline)}`
          )
        );

        if (x.catatan) {
          kiri.append(
            buatElemen("div", "detail-tugas mt-1", x.catatan)
          );
        }

        const kanan = buatElemen("div", "aksi-tugas");

        let status = namaPrioritas(x.prioritas);
        let kelas = "chip-" + x.prioritas.toLowerCase();

        if (x.status === "selesai") {
          status = t("statDone");
          kelas = "chip-selesai";
        } else if (terlambat(x)) {
          status = t("statLate");
          kelas = "chip-terlambat";
        }

        kanan.append(
          buatElemen("span", "chip " + kelas, status)
        );

        const aksi = [
          [x.status === "selesai" ? t("reopen") : t("markDone"), "toggle", "btn-outline-success"],
          [t("edit"), "edit", "btn-outline-secondary"],
          [t("del"), "hapus", "btn-outline-danger"]
        ];

        aksi.forEach(([nama, jenis, gaya]) => {
          const tombol = buatElemen("button", "btn " + gaya, nama);
          tombol.type = "button";
          tombol.dataset.aksi = jenis;
          tombol.dataset.id = x.id;
          kanan.append(tombol);
        });

        baris.append(kiri, kanan);
        wadah.append(baris);
      });
    }

    // DATA DASHBOARD

    function renderBeranda() {
      const data = tugasUser();

      const selesai = data.filter(
        x => x.status === "selesai"
      ).length;

      const terlambatJumlah = data.filter(terlambat).length;

      $("stat-total").textContent = data.length;
      $("stat-aktif").textContent = data.length - selesai;
      $("stat-selesai").textContent = selesai;
      $("stat-terlambat").textContent = terlambatJumlah;

      const persen = data.length
        ? Math.round((selesai / data.length) * 100)
        : 0;

      $("persentase").textContent = persen + "%";
      $("progres-bar").style.width = persen + "%";

      isiDaftar(
        "daftar-beranda",
        urutkan(data.filter(x => x.status !== "selesai")).slice(0, 4)
      );
    }

    // PENCARIAN DAN FILTER

    function renderDaftar() {
      const cari = $("cari-tugas").value.trim().toLowerCase();
      const filter = $("filter-tugas").value;

      const hasil = urutkan(
        tugasUser().filter(x => {
          const cocok = (x.judul + " " + x.matkul)
            .toLowerCase()
            .includes(cari);

          return cocok && (
            filter === "semua" ||
            (filter === "terlambat"
              ? terlambat(x)
              : x.status === filter)
          );
        })
      );

      isiDaftar("daftar-semua", hasil);
    }

    // KALENDER

function renderKalender() {
  if (kalPilih == null) {
    kalPilih = tanggalHariIni();
  }

  // kelompokkan tugas berdasarkan tanggal deadline
  var peta = {};
  var semuaTugas = tugasUser();
  for (var i = 0; i < semuaTugas.length; i++) {
    var tugas = semuaTugas[i];
    if (peta[tugas.deadline] == null) {
      peta[tugas.deadline] = [];
    }
    peta[tugas.deadline].push(tugas);
  }

  var y = kalBulan.getFullYear();
  var m = kalBulan.getMonth();

  // cari jumlah hari dalam bulan ini pakai if
  var jumlahHari = 0;
  if (m == 0 || m == 2 || m == 4 || m == 6 || m == 7 || m == 9 || m == 11) {
    jumlahHari = 31;
  } else if (m == 3 || m == 5 || m == 8 || m == 10) {
    jumlahHari = 30;
  } else {
    // Februari
    if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0) {
      jumlahHari = 29;
    } else {
      jumlahHari = 28;
    }
  }

  // cari geser hari pertama, Senin = 0
  var hariPertama = new Date(y, m, 1).getDay();
  var geser = 0;
  if (hariPertama == 0) {
    geser = 6;
  } else {
    geser = hariPertama - 1;
  }

  var hariIni = tanggalHariIni();

  // judul bulan
  var judul = $("kal-judul");
  judul.textContent = kalBulan.toLocaleDateString(lokal(), {
    month: "long",
    year: "numeric"
  });

  var grid = $("kal-grid");
  grid.innerHTML = "";

  // nama hari Senin - Minggu
  var namaHari = t("days");
  var html = "";
  for (var h = 0; h < namaHari.length; h++) {
    html = html + '<div class="kal-nama-hari">' + namaHari[h] + "</div>";
  }

  // kotak kosong sebelum tanggal 1
  for (var k = 0; k < geser; k++) {
    html = html + '<div class="kal-kosong"></div>';
  }

  for (var d = 1; d <= jumlahHari; d++) {
    var kunci = y + "-" + dua(m + 1) + "-" + dua(d);

    var daftar = [];
    if (peta[kunci] != null) {
      daftar = peta[kunci];
    }

    var kelas = "kal-hari";
    if (kunci == hariIni) {
      kelas = kelas + " hariini";
    }
    if (kunci == kalPilih) {
      kelas = kelas + " dipilih";
    }

    var label = tglIndo(kunci);
    if (daftar.length > 0) {
      label = label + ", " + t("calTaskCount", { n: daftar.length });
    }

    html = html + '<button type="button" class="' + kelas + '" data-tanggal="' + kunci + '" aria-label="' + label + '">';
    html = html + '<span class="kal-angka">' + d + "</span>";

    if (daftar.length > 0) {
      html = html + '<span class="kal-penanda">';

      var daftarUrut = urutkan(daftar);
      var batas = 3;
      if (daftarUrut.length < 3) {
        batas = daftarUrut.length;
      }
      for (var j = 0; j < batas; j++) {
        html = html + '<i class="titik titik-' + statusTugas(daftarUrut[j]) + '"></i>';
      }

      if (daftar.length > 3) {
        html = html + "<span>+" + (daftar.length - 3) + "</span>";
      }

      html = html + "</span>";
    }

    html = html + "</button>";
  }

  grid.innerHTML = html;

  $("kal-judul-hari").textContent = t("calTasksOn", { d: tglIndo(kalPilih) });

  var tugasDipilih = [];
  if (peta[kalPilih] != null) {
    tugasDipilih = peta[kalPilih];
  }

  isiDaftar(
    "daftar-kalender",
    urutkan(tugasDipilih),
    t("calNone")
  );
}

    // PENGATURAN

function renderPilihan() {
  var tombolTema = document.querySelectorAll("[data-pilih-tema]");
  for (var i = 0; i < tombolTema.length; i++) {
    var b = tombolTema[i];
    if (b.dataset.pilihTema == pref.tema) {
      b.classList.add("btn-hijau");
      b.classList.remove("btn-outline-success");
    } else {
      b.classList.remove("btn-hijau");
      b.classList.add("btn-outline-success");
    }
  }

  var tombolBahasa = document.querySelectorAll("[data-pilih-bahasa]");
  for (var j = 0; j < tombolBahasa.length; j++) {
    var b2 = tombolBahasa[j];
    if (b2.dataset.pilihBahasa == pref.bahasa) {
      b2.classList.add("btn-hijau");
      b2.classList.remove("btn-outline-success");
    } else {
      b2.classList.remove("btn-hijau");
      b2.classList.add("btn-outline-success");
    }
  }
}

function renderPengaturan() {
  var u = user();
  if (!u) {
    return;
  }

  $("nama-ubah").value = u.nama;
  $("email-set").textContent = u.email;
  $("pesan-nama").classList.add("d-none");
  renderPilihan();
}

function terapkanTema() {
  document.documentElement.setAttribute("data-tema", pref.tema);
  document.documentElement.setAttribute("data-bs-theme", pref.tema);
}

function terapkanBahasa() {
  document.documentElement.lang = pref.bahasa;
  document.title = t("title");

  var daftar1 = document.querySelectorAll("[data-i18n]");
  for (var i = 0; i < daftar1.length; i++) {
    var e1 = daftar1[i];
    e1.textContent = t(e1.dataset.i18n);
  }

  var daftar2 = document.querySelectorAll("[data-i18n-html]");
  for (var j = 0; j < daftar2.length; j++) {
    var e2 = daftar2[j];
    e2.innerHTML = t(e2.dataset.i18nHtml);
  }

  var daftar3 = document.querySelectorAll("[data-i18n-ph]");
  for (var k = 0; k < daftar3.length; k++) {
    var e3 = daftar3[k];
    e3.placeholder = t(e3.dataset.i18nPh);
  }

  segarkan();
}

function segarkan() {
  if (user()) {
    tampil(halaman);
  } else {
    tampil(panelAuth);
  }
}

// NAVIGASI HALAMAN

var SEMUA_HALAMAN = ["beranda", "tugas", "kalender", "tambah", "pengaturan"];

function tampil(ke) {
  var u = user();

  if (u) {
    $("layar-auth").classList.add("d-none");
    $("layar-app").classList.remove("d-none");
  } else {
    $("layar-auth").classList.remove("d-none");
    $("layar-app").classList.add("d-none");
  }

  if (!u) {
    if (ke == "daftar") {
      panelAuth = "daftar";
    } else {
      panelAuth = "login";
    }
    if (panelAuth == "daftar") {
      $("panel-daftar").classList.remove("d-none");
      $("panel-login").classList.add("d-none");
    } else {
      $("panel-daftar").classList.add("d-none");
      $("panel-login").classList.remove("d-none");
    }
    return;
  }

  // cek apakah ke ada di SEMUA_HALAMAN
  var ketemu = false;
  for (var i = 0; i < SEMUA_HALAMAN.length; i++) {
    if (SEMUA_HALAMAN[i] == ke) {
      ketemu = true;
    }
  }
  if (ketemu) {
    halaman = ke;
  } else {
    halaman = "beranda";
  }

  $("nama-profil").textContent = u.nama || t("userDefault");
  $("email-profil").textContent = u.email;

  for (var h = 0; h < SEMUA_HALAMAN.length; h++) {
    var namaHalaman = SEMUA_HALAMAN[h];
    if (halaman == namaHalaman) {
      $("halaman-" + namaHalaman).classList.remove("d-none");
    } else {
      $("halaman-" + namaHalaman).classList.add("d-none");
    }
  }

  var tombolHalaman = document.querySelectorAll("[data-halaman]");
  for (var b = 0; b < tombolHalaman.length; b++) {
    var tombol = tombolHalaman[b];
    if (tombol.dataset.halaman == halaman) {
      tombol.classList.add("aktif");
    } else {
      tombol.classList.remove("aktif");
    }
  }

  var judul = "";
  var sub = "";
  if (halaman == "beranda") {
    judul = t("navHome");
    sub = t("homeSub", { n: u.nama });
  } else if (halaman == "tugas") {
    judul = t("navTasks");
    sub = t("tasksSub");
  } else if (halaman == "kalender") {
    judul = t("navCal");
    sub = t("calSub");
  } else if (halaman == "tambah") {
    if ($("id-tugas").value) {
      judul = t("editTitle");
    } else {
      judul = t("addTitle");
    }
    sub = t("addSub");
  } else if (halaman == "pengaturan") {
    judul = t("navSet");
    sub = t("setSub");
  }

  $("judul-halaman").textContent = judul;
  $("subjudul-halaman").textContent = sub;

  if (halaman == "tambah") {
    $("aksi-tambah").classList.add("d-none");
  } else {
    $("aksi-tambah").classList.remove("d-none");
  }

  if (halaman == "beranda") {
    renderBeranda();
  }
  if (halaman == "tugas") {
    renderDaftar();
  }
  if (halaman == "kalender") {
    renderKalender();
  }
  if (halaman == "pengaturan") {
    renderPengaturan();
  }

  window.scrollTo(0, 0);
}

// FORM TAMBAH / EDIT

function formKosong() {
  $("form-tugas").reset();
  $("id-tugas").value = "";
  $("deadline-tugas").value = tanggalHariIni();
}

function bukaForm(id, tanggal) {
  if (id == null) {
    id = "";
  }
  if (tanggal == null) {
    tanggal = "";
  }

  if (halaman != "tambah") {
    asalForm = halaman;
  }

  formKosong();

  if (tanggal) {
    $("deadline-tugas").value = tanggal;
  }

  if (id) {
    var semua = tugasUser();
    var x = null;
    for (var i = 0; i < semua.length; i++) {
      if (semua[i].id == id) {
        x = semua[i];
      }
    }
    if (!x) {
      return;
    }

    $("id-tugas").value = x.id;
    $("judul-tugas").value = x.judul;
    $("matkul-tugas").value = x.matkul;
    $("deadline-tugas").value = x.deadline;
    $("prioritas-tugas").value = x.prioritas;
    $("status-tugas").value = x.status;
    $("catatan-tugas").value = x.catatan;
  }

  tampil("tambah");
}

// LOGIN

function masukKeApp(u) {
  sessionStorage.setItem(K_SESI, u.id);
  tampil("beranda");
}

function keluar() {
  sessionStorage.removeItem(K_SESI);
  halaman = "beranda";
  tampil("login");
}

// AKUN DEMO

var sudahAdaDemo = false;
var cekAkun = akunSemua();
for (var d = 0; d < cekAkun.length; d++) {
  if (cekAkun[d].email == "demo@tugasin.test") {
    sudahAdaDemo = true;
  }
}

if (!sudahAdaDemo) {
  var akun = akunSemua();

  var akunBaru = {};
  akunBaru.id = "demo";
  akunBaru.nama = "Mahasiswa Demo";
  akunBaru.email = "demo@tugasin.test";
  akunBaru.password = "demo1234";

  akun.push(akunBaru);

  simpan(K_AKUN, akun);
}

// PROSES LOGIN

$("form-login").addEventListener("submit", function(e) {
  e.preventDefault();

  $("pesan-login").classList.add("d-none");

  var email = $("email-login").value.trim().toLowerCase();
  var pass = $("password-login").value;

  var semuaAkun = akunSemua();
  var u = null;
  for (var i = 0; i < semuaAkun.length; i++) {
    if (semuaAkun[i].email == email && semuaAkun[i].password == pass) {
      u = semuaAkun[i];
    }
  }

  if (!u) {
    pesan("pesan-login", t("errLogin"));
    return;
  }

  $("form-login").reset();
  masukKeApp(u);
});

// PROSES DAFTAR

$("form-daftar").addEventListener("submit", function(e) {
  e.preventDefault();

  $("pesan-daftar").classList.add("d-none");

  var nama = $("nama-daftar").value.trim();
  var email = $("email-daftar").value.trim().toLowerCase();
  var password = $("password-daftar").value;

  if (nama.length < 2 || password.length < 6) {
    pesan("pesan-daftar", t("errShort"));
    return;
  }

  var semua = akunSemua();

  var sudahDipakai = false;
  for (var i = 0; i < semua.length; i++) {
    if (semua[i].email == email) {
      sudahDipakai = true;
    }
  }

  if (sudahDipakai) {
    pesan("pesan-daftar", t("errDup"));
    return;
  }

  var u = {};
  u.id = buatId();
  u.nama = nama;
  u.email = email;
  u.password = password;

  semua.push(u);
  simpan(K_AKUN, semua);

  $("form-daftar").reset();
  masukKeApp(u);
});

// MASUK DEMO

$("tombol-demo").addEventListener("click", function() {
  var semuaAkun = akunSemua();
  var u = null;
  for (var i = 0; i < semuaAkun.length; i++) {
    if (semuaAkun[i].email == "demo@tugasin.test") {
      u = semuaAkun[i];
    }
  }

  if (u) {
    masukKeApp(u);
  }
});

// LOGOUT DAN GANTI AKUN

$("tombol-keluar").addEventListener("click", keluar);
$("tombol-keluar2").addEventListener("click", keluar);

$("tombol-ganti").addEventListener("click", function() {
  keluar();
  $("email-login").focus();
});

// UBAH NAMA PROFIL

$("form-nama").addEventListener("submit", function(e) {
  e.preventDefault();

  var u = user();
  if (!u) {
    return;
  }

  var nama = $("nama-ubah").value.trim();

  if (nama.length < 2) {
    pesan("pesan-nama", t("errName"));
    return;
  }

  var semua = akunSemua();
  var idx = -1;
  for (var i = 0; i < semua.length; i++) {
    if (semua[i].id == u.id) {
      idx = i;
    }
  }
  if (idx < 0) {
    return;
  }

  semua[idx].nama = nama;
  simpan(K_AKUN, semua);

  tampil("pengaturan");
  pesan("pesan-nama", t("nameSaved"), true);
});

// TEMA DAN BAHASA

var pilihTema = document.querySelectorAll("[data-pilih-tema]");
for (var t1 = 0; t1 < pilihTema.length; t1++) {
  pilihTema[t1].addEventListener("click", function() {
    pref.tema = this.dataset.pilihTema;
    simpan(K_PREF, pref);
    terapkanTema();
    renderPilihan();
  });
}

var pilihBahasa = document.querySelectorAll("[data-pilih-bahasa]");
for (var t2 = 0; t2 < pilihBahasa.length; t2++) {
  pilihBahasa[t2].addEventListener("click", function() {
    pref.bahasa = this.dataset.pilihBahasa;
    simpan(K_PREF, pref);
    terapkanBahasa();
  });
}

// NAVIGASI MENU

$("aksi-tambah").addEventListener("click", function() {
  bukaForm();
});

var menuHalaman = document.querySelectorAll("[data-halaman]");
for (var m1 = 0; m1 < menuHalaman.length; m1++) {
  menuHalaman[m1].addEventListener("click", function() {
    if (this.dataset.halaman == "tambah") {
      bukaForm();
    } else {
      tampil(this.dataset.halaman);
    }
  });
}

// PENCARIAN

$("cari-tugas").addEventListener("input", renderDaftar);
$("filter-tugas").addEventListener("change", renderDaftar);

// KALENDER: PILIH TANGGAL, GANTI BULAN

$("kal-grid").addEventListener("click", function(e) {
  var b = e.target.closest("[data-tanggal]");
  if (!b) {
    return;
  }

  kalPilih = b.dataset.tanggal;
  renderKalender();
});

$("kal-prev").addEventListener("click", function() {
  kalBulan = new Date(kalBulan.getFullYear(), kalBulan.getMonth() - 1, 1);
  renderKalender();
});

$("kal-next").addEventListener("click", function() {
  kalBulan = new Date(kalBulan.getFullYear(), kalBulan.getMonth() + 1, 1);
  renderKalender();
});

$("kal-hariini").addEventListener("click", function() {
  var n = new Date();
  kalBulan = new Date(n.getFullYear(), n.getMonth(), 1);
  kalPilih = tanggalHariIni();
  renderKalender();
});

$("kal-tambah").addEventListener("click", function() {
  bukaForm("", kalPilih);
});

// SIMPAN TUGAS

$("form-tugas").addEventListener("submit", function(e) {
  e.preventDefault();

  var u = user();
  if (!u) {
    return;
  }

  var id = $("id-tugas").value;

  var data = {};
  if (id) {
    data.id = id;
  } else {
    data.id = buatId();
  }
  data.userId = u.id;
  data.judul = $("judul-tugas").value.trim();
  data.matkul = $("matkul-tugas").value.trim();
  data.deadline = $("deadline-tugas").value;
  data.prioritas = $("prioritas-tugas").value;
  data.status = $("status-tugas").value;
  data.catatan = $("catatan-tugas").value.trim();

  if (!data.judul || !data.matkul || !data.deadline) {
    return;
  }

  var semua = tugasSemua();

  var idx = -1;
  for (var i = 0; i < semua.length; i++) {
    if (semua[i].id == id && semua[i].userId == u.id) {
      idx = i;
    }
  }

  if (idx >= 0) {
    semua[idx] = data;
  } else {
    semua.push(data);
  }

  simpan(K_TUGAS, semua);

  // kalender langsung menunjuk ke tanggal tugas yang baru disimpan
  var potong = data.deadline.split("-");
  var yy = parseInt(potong[0]);
  var mm = parseInt(potong[1]);
  kalBulan = new Date(yy, mm - 1, 1);
  kalPilih = data.deadline;

  formKosong();
  if (asalForm == "kalender") {
    tampil("kalender");
  } else {
    tampil("tugas");
  }
});

// EDIT, HAPUS, DAN SELESAIKAN TUGAS

document.addEventListener("click", function(e) {
  var b = e.target.closest("[data-aksi]");

  if (!b || !user()) {
    return;
  }

  var id = b.dataset.id;
  var aksi = b.dataset.aksi;
  var u = user();

  var semua = tugasSemua();

  var idx = -1;
  for (var i = 0; i < semua.length; i++) {
    if (semua[i].id == id && semua[i].userId == u.id) {
      idx = i;
    }
  }

  if (idx < 0) {
    return;
  }

  if (aksi == "edit") {
    bukaForm(id);
    return;
  }

  if (aksi == "hapus") {
    if (!confirm(t("confirmDel"))) {
      return;
    }
    semua.splice(idx, 1);
  }

  if (aksi == "toggle") {
    if (semua[idx].status == "selesai") {
      semua[idx].status = "aktif";
    } else {
      semua[idx].status = "selesai";
    }
  }

  simpan(K_TUGAS, semua);
  tampil(halaman);
});

// PERPINDAHAN LOGIN DAN DAFTAR

function sinkronHash() {
  if (!user()) {
    if (location.hash == "#daftar") {
      tampil("daftar");
    } else {
      tampil("login");
    }
  } else if (location.hash == "#beranda") {
    tampil("beranda");
  }
}

window.addEventListener("hashchange", sinkronHash);

// JALANKAN APLIKASI

try {
  if (location.hash == "#daftar") {
    panelAuth = "daftar";
  } else {
    panelAuth = "login";
  }
  terapkanTema();
  terapkanBahasa();
} catch (error) {
  console.error(error);
  alert(t("errStorage"));
}
